REPORT coursesstatus
============================

A Moodle admin report. Show the list of courses and some information about these.

Package tested in: moodle 3.3+

QUICK INSTALL
==============
Download zip package, extract the coursesstatus folder and upload this folder into report/.

ABOUT
=============
Developed by: David Herney Bernal García - davidherney at gmail dot com
GIT: https://github.com/davidherney/moodle-report_coursesstatus

IN VERSION
=============
2017080302:
Changed deprecated function pix_url

2017080301:
Fix issue: #1 - Fails on PostgreSQL

2017080300:
Started as a public project
